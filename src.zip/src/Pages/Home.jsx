import React from "react";
import Header from "../components/Header";
import CandidatePresentation from "../components/Presentation";
import TabsSection from "../components/TabsSection";
import PartnersSection from "../components/PartnersSection";
import TestimonialsSection from "../components/TestimonialsSection";
import FeatureSection from "../components/FeatureSection";
import Markiting from "../components/Markiting"
import CandidateSec from "../components/CantidateSec";
import StatsSection from "../components/StatSection";
import BrandingSection from "../components/BrandingSection";
import IntegrationSection from "../components/Integration";
import SecuritySection from "../components/SecuritySection";
import Testimonal from "../components/Testimonal"
import CandidateVideo from "../components/CamdidateVideo";
import DemoSection from "../components/DemoSection";
import Footer from "../components/Footer";


function Home() {
  return (
    <div>
      <Header/>
      < CandidatePresentation/>
      <TabsSection/>
      <PartnersSection/>
      <TestimonialsSection/>
      <FeatureSection/>
      <Markiting/>
      <CandidateSec/>
      <StatsSection/>
      <BrandingSection/>
      <IntegrationSection/>
      <SecuritySection/>
      <Testimonal/>
      <CandidateVideo/>
      <DemoSection/>
      <Footer/>
    </div>
  );
}

export default Home;
