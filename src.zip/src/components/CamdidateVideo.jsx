import React from "react";


export default function CandidateVideo() {
    return (

        <section className="w-[80%] m-auto my-[50px] py-10">
          
          <div className="font-semibold leading-tight m-auto py-5 text-5xl text-center">
              <h2 className="text-[#1f1751]">Your candidate is your product.</h2>
              <h2 className="text-blue-600">Make your product shine.</h2>
              <h2 className="text-[#1f1751]">Every time.</h2>
              <a
          href="#"
          className="px-10 py-2 mt-5 border-2 text-xl font-semibold border-blue-600 bg-blue-600 text-white rounded-tr-xl rounded-bl-xl hover:bg-white hover:text-blue-600"
        >
          Try it out &gt;&gt;
        </a>
          </div>

          <div className=" overflow-hidden w-[90%] mt-20 m-auto">
          <video
            className="w-full h-full object-cover"
            src="/images/Candidate-video-4.mp4"
            autoPlay
            loop
            muted
            playsInline
          />
        </div>


        </section>





    );
}