// CandidateSection.jsx
import React from "react";

export default function CandidateSection() {
    return (
        <section className="w-full  py-16  my-[100px] bg-gray-100 ">
            <div className="w-[50%] mx-auto px-6 text-center ">
                {/* Heading */}
                <h2 className="text-4xl md:text-4xl font-semibold text-gray-800 leading-tight" >
                    Present your candidates like the top tier exec search firms
                </h2>
                <p className="text-lg md:text-xl text-gray-600 mt-4">
                    They have researchers,{" "}
                    <span className="italic font-semibold text-blue-600">you have AI</span>
                </p>

                {/* CTA Button */}
                <div className="mt-6">
                    <a
                        href="#"
                        className="px-4 py-2 border-2 text-lg font-semibold border-blue-600 bg-blue-600 text-white rounded-tr-xl rounded-bl-xl hover:bg-white hover:text-blue-600"
                    >
                        Explore Products &gt;&gt;
                    </a>
                </div>
            </div>

            {/* Features Grid */}
            <div className="max-w-[80%] mx-auto px-6 mt-16 grid md:grid-cols-2 gap-12 ">
                {/* Feature 1 */}
                <div>
                    <div className="h-[180px]">
                        <h3 className="text-xl font-bold text-gray-800">FORMATTED PROFILE</h3>
                    <p className="text-gray-600 font-semibold my-5 leading-relaxed">
                        The standard for candidate presentation. Use<br /> HireAra to present
                        consistent, quality CVs that make <br />life easier for hiring managers and
                        your consultants
                    </p>
                    </div>
                    <img
                        src="/images/cv-type1.png"
                        alt="Candidate Reports"
                     className="rounded-xl shadow-lg h-[460px]  border-2 border-[#b8d8f1] bg-gradient-to-b from-white to-[#b8d8f1]" />

                </div>

                {/* Feature 2 */}
                <div>
                    <div className=" h-[180px]">
                         <h3 className="text-xl font-bold text-gray-800">CANDIDATE REPORTS</h3>
                    <p className="text-gray-600 my-5 font-semibold leading-relaxed">
                        A candidate report is a concise, structured overview highlighting a
                        candidate’s key skills, experience, and fit. It helps hiring managers
                        make quick, informed <br />shortlisting decisions.
                    </p>
                    </div>
                   
                    <img
                        src="/images/cv-type2.png"
                        alt="Candidate Reports"
                     className="rounded-xl shadow-lg h-[460px]  border-2 border-[#95e2ce] bg-gradient-to-b from-white to-[#95e2ce]" />
                </div>

                {/* Feature 3 */}
                <div>
                    <div className=" h-[180px]">
                         <h3 className="text-xl font-bold text-gray-800">ONE PAGER</h3>
                    <p className="text-gray-600 my-5 font-semibold leading-relaxed">
                       An executive overview that distills your candidates qualities in 1 page. Make it easy for your hiring manager to understand your candidate, quickly. Excellent for upselling more candidates
                    </p>
                    </div>
                   
                    <img
                        src="/images/cv-type3.png"
                        alt="Candidate Reports"
                     className="rounded-xl shadow-lg h-[460px]  border-2 border-[#c6efde] bg-gradient-to-b from-white to-[#c6efde]" />
                </div>

                {/* Feature 4 */}
                <div>
                    <div className="h-[180px]">
                         <h3 className="text-xl font-bold text-gray-800">ONE PAGER</h3>
                    <p className="text-gray-600 my-5 font-semibold leading-relaxed">
                        An executive overview that distills your candidates’ qualities in 1
                        page. Make it easy for your hiring manager to understand your
                        candidate quickly. Excellent for upselling more candidates.
                    </p>
                    </div>
                   
                    <img
                        src="/images/cv-type4.png"
                        alt="Candidate Reports"
                     className="rounded-xl shadow-lg h-[460px]  border-2 border-[#c8b6ff] bg-gradient-to-b from-white to-[#c8b6ff]"/>
                </div>
            </div>
        </section>
    );
}
