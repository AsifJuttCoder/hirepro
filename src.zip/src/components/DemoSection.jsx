import React from "react";

export default function DemoSection() {
  return (
    <section className="bg-[linear-gradient(to_bottom_right,#1f0f5f,#0d0c28,#285877)] pt-16 px-6 md:px-12 lg:px-20  relative w-[72%] m-auto rounded-2xl flex justify-between">
    

    <div className="">
        <h1 className="text-4xl md:text-5xl font-normal leading-snug">
        <span className="text-[#DCD0FF]">Ready to try</span>{" "}
        <span className="text-white font-medium">HireAra?</span>
      </h1>

      <h2 className="text-lg text-[#CBB8FF] font-semibold mt-2">
        Book a demo with our team to see the platform live!
      </h2>

      {/* Buttons */}
      <div className="flex flex-col sm:flex-row  gap-4 mt-6">
        <a
          className="bg-white text-blue-600 px-6 py-2 rounded-tr-xl rounded-bl-xl font-medium hover:bg-blue-600 hover:text-white transition"
        >
          Virtual Product Demo &gt;&gt;
        </a>
        <a
          className="bg-blue-600 text-white px-6 py-2  rounded-tr-xl rounded-bl-xl font-medium hover:bg-white hover:text-blue-600 transition"
        >
          Book a Demo &gt;&gt;
        </a>
      </div>
    </div>
    

    <div className="relative w-[50%] h-[370px]">
       {/* Extra Text */}
      <h3 className="text-lg font-medium text-gray-200 absolute top-2 right-8">Place</h3>
      <h3 className="text-lg font-medium text-gray-200 absolute top-12 right-40">Present</h3>
      <h3 className="text-lg font-medium text-gray-200 absolute top-40 left-30">Pitch</h3>

     
      
        <img
          src="/images/CV-2.png"
          alt="Pitch Present Place"
          className="w-[268px] h-[263px] object-cover absolute top-20 right-10"
        />

        {/* Small floating image (top-right corner) */}
        <img
          src="/images/CV-3.png"
          alt="Pitch Present Place Small"
          className="w-[97px] h-[119px] object-cover absolute top-10 right-0"
        />

        {/* Wide image (bottom-right) */}
        <img
          src="/images/CV-1.png"
          alt="Pitch Present Place Wide"
          className="w-[248px] h-[154px] object-cover absolute top-48 left-10"
        />
      </div>

     
    </section>
  );
}
