// CandidatePresentation.jsx
import React from "react";

export default function CandidatePresentation() {
  return (
    <div className="lg:w-[76%] sm:w-[95%] m-auto mt-25 p-2"> 
      <a href="">
        <div className=" border border-green-500 h-10 w-[60%] m-auto rounded-4xl flex items-center justify-center shadow bg-green-100">
          <p className="text-lg  font-semibold ">
            Register a HireAra Win and stand a chance to win{" "}
            <span className="text-blue-500 font-bold">£776.67</span>
          </p>
        </div>
      </a>

      <h2 className="sm:text-4xl md:text-5xl lg:text-6xl font-normal leading-tight text-center mt-10">
        We present <span className="text-blue-700">millions</span> of candidates on behalf of{" "}
        <span className="text-blue-700"> 5000+ </span> recruiters
      </h2>

      <p className="w-[73%] m-auto text-2xl text-center font-normal my-5">
        Present every candidate like a superstar with the market-leading, AI-powered Candidate Presentation platform. Proven to drive outreach and boost CV conversion.
      </p>

      <div className="w-[40%] m-auto p-2 flex justify-around">
        <a
          href="#"
          className="px-10 py-2 border-2 border-blue-600 bg-blue-600 text-white rounded-tr-xl rounded-bl-xl hover:bg-white hover:text-blue-600"
        >
          Book a demo
        </a>
        <a
          href="#"
          className="p-2 border-2 border-blue-600 bg-white text-blue-600 rounded-tr-xl rounded-bl-xl hover:bg-blue-600 hover:text-white"
        >
          Virtual Product demo
        </a>
      </div>

      {/* Last 8 images section */}
    <div className="w-[42%] m-auto my-3 p-2 flex justify-evenly items-center"> <p>Integrated With:</p>

        {[
          "/images/CRM.png",
          "/images/CRM-1.png",
          "/images/CRM-2.png",
          "/images/CRM-3.png",
          "/images/CRM-4.png",
          "/images/CRM-5.png",
          "/images/CRM-6.png",
          "/images/CRM-7.png",
        ].map((src, index) => (
          <div
            key={index}
            className="h-[30px] w-[30px] border-2 border-gray-400 rounded-xl overflow-hidden transition-transform duration-300 ease-in-out hover:-translate-y-2"
          >
            <img src={src} alt={`crm-${index}`} className="w-full h-full object-contain" />
          </div>
        ))}
      </div>
    </div>
  );
}
