import React from "react";

export default function SecuritySection() {
  return (
    <section className="bg-[#0c1228] py-16  ">
     <div className="w-[80%] m-auto text-white ">
        <div className="flex  items-center ">
           <div className=" w-[38%] mx-auto  h-[auto] ">
        <h1 className="text-4xl font-semibold leading-snug">
          Security and Privacy that you can count on
        </h1>
        <h2 className="text-base font-extralight  mt-4">
          From a secure platform that improves your data security
        </h2>

        <div className="mt-6">
          <a
            href="https://www.hireara.ai/security"
            className="inline-block bg-green-500 text-white font-medium rounded-lg px-6 py-2 hover:bg-green-600 transition"
          >
            Security Centre &gt;&gt;
          </a>
        </div>
      </div>

      {/* Security Logos */}
      <div className="flex flex-wrap justify-between  items-center  w-[35%] ">
        <div className=" bg-white p-2 rounded-2xl"> 
          <img
          src="https://static.wixstatic.com/media/f9fb77_f362d03b1d8943a59b9a49e8801db200~mv2.png/v1/fill/w_147,h_147,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/Security%20Logo-13.png"
          alt="ISO 27001"
          className="w-36 h-36 object-cover"
        />
        </div>
        <div className=" flex flex-col gap-9">
         <div className="bg-white p-2 rounded-2xl">
           <img
          src="https://static.wixstatic.com/media/f9fb77_5ccfbb3c57f84e139a21faa1a52effce~mv2.png/v1/fill/w_154,h_154,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/Security%20Logo-12.png"
          alt="Cyber Essentials Certified"
          className="w-36 h-36 object-cover"
        />
         </div>
       <div className="bg-white p-2 rounded-2xl">
         <img
          src="https://static.wixstatic.com/media/f9fb77_833108c007444ee88cf69d7c2e79e2f4~mv2.png/v1/fill/w_153,h_152,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/Security%20Logo-11.png"
          alt="GDPR Compliant"
          className="w-36 h-36 object-cover"
        />
       </div>
        </div>
      </div>
        </div>

      {/* Links Section */}
      <div className="mt-12 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 text-center">
        <div>
          <img
            src="https://static.wixstatic.com/media/f9fb77_61ed677645d744b5850b4fd5e51824ca~mv2.png/v1/fill/w_64,h_62,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/icons%20png.png"
            alt="Status Icon"
            className="mx-auto w-12 h-12"
          />
          <a
            href="https://hireara.statuspage.io/"
            target="_blank"
            rel="noreferrer"
            className="text-green-500 font-bold underline text-sm mt-2 block"
          >
            HireAra Status
          </a>
        </div>

        <div>
          <img
            src="https://static.wixstatic.com/media/f9fb77_0560a3fe111d4e34acc504c74e3c7b29~mv2.png/v1/fill/w_57,h_60,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/icons%20png-04.png"
            alt="Charter Icon"
            className="mx-auto w-12 h-12"
          />
          <a
            href="https://www.hireara.ai/hireara-ai-charter"
            className="text-green-500 font-bold underline text-sm mt-2 block"
          >
            HireAra AI Charter
          </a>
        </div>

        <div>
          <img
            src="https://static.wixstatic.com/media/f9fb77_8c531748e4bf46a084d60a3bd2aac32d~mv2.png/v1/fill/w_70,h_50,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/f9fb77_8c531748e4bf46a084d60a3bd2aac32d~mv2.png"
            alt="FAQ Icon"
            className="mx-auto w-12 h-12 "
          />
          <a
            href="https://www.hireara.ai/candidatefaq-howhirearausesaitohe-hireara"
            className="text-green-500 font-bold underline text-sm mt-2 block"
          >
            View Candidate FAQ's
          </a>
        </div>

        <div>
          <img
            src="https://static.wixstatic.com/media/f9fb77_0f5d8cd15cd3493ca7fd853a0fab4a64~mv2.png/v1/fill/w_50,h_62,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/icons%20png-05.png"
            alt="Privacy Policy Icon"
            className="mx-auto w-12 h-12"
          />
          <a
            href="https://www.hireara.ai/privacypolicy"
            target="_blank"
            rel="noreferrer"
            className="text-green-500 font-bold underline text-sm mt-2 block"
          >
            HireAra's Privacy Policy
          </a>
        </div>
      </div>
     </div>
    </section>
  );
}
