// PartnersSection.jsx
import React from "react";

export default function PartnersSection() {
  const logos = [
    "/images/partner-1.png",
    "/images/partner-2.png",
    "/images/partner-3.png",
    "/images/partner-4.png",
    "/images/partner-5.png",
    "/images/partner-6.png",
    "/images/partner-7.png",
    "/images/partner-8.png",
  ];

  return (
    <section className="w-full py-10 bg-white-100 mt-[100px]">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-2xl md:text-2xl  text-center mb-20">
          More than <span className="text-blue-600">5,000</span> recruiters use HireAra everyday
        </h2>

        {/* Logo Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6 items-center justify-items-center w-[80%] m-auto">
          {logos.map((logo, index) => (
            <div
              key={index}
              className="h-14 flex items-center justify-center "
            >
              <img
                src={logo}
                alt={`partner-${index}`}
                className="max-h-full object-contain grayscale hover:grayscale-0 transition duration-300"
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}