import { useState } from "react";

export default function TabsSection() {
  const [activeTab, setActiveTab] = useState("candidate");

  const tabs = [
    {
      id: "candidate",
      label: "✐ Candidate Presentation",
      img: "/images/Candidate Presentation.png",
      text: "Create unlimited candidate content",
    },
    {
      id: "ai",
      label: "✧ AI Assist",
      img: "/images/AI Assist.png",
      text: "AI personalised content for every role",
    },
    {
      id: "analytics",
      label: "❏ Landing Page & Analytics",
      img: "/images/Landing Page.png",
      text: "Real-time notifications & analytics",
    },
    {
      id: "distribution",
      label: "⇪ Distribution",
      img: "/images/Distribution.png",
      text: "Submit via any channel",
    },
  ];

  return (
    <div className="w-full max-w-5xl mx-auto mt-[150px] bg-gray-100">
      {/* Tabs Header */}
      <div className="flex items-center justify-center gap-4 border-b border-gray-300 bg-white overflow-x-auto">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 text-sm font-medium focus:outline-none transition ${
              activeTab === tab.id
                ? "border-b-2 border-cyan-500"
                : "text-gray-600 hover:text-cyan-500 hover:border-b-2 hover:border-cyan-500"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tabs Content */}
      <div className="mt-6">
        {tabs.map((tab) =>
          activeTab === tab.id ? (
            <div key={tab.id}>
                <h2 className="text-center text-2xl mt-7 font-semibold">{tab.text}</h2>
              <img
                src={tab.img}
                alt={tab.label}
                className="rounded-[20px] w-full object-cover shadow-md"
              />
              
            </div>
          ) : null
        )}
      </div>
    </div>
  );
}