export default function StatsSection() {
  return (
    <section className="bg-[#0d0c29] py-30 my-20 ">
      <div className="max-w-6xl mx-auto text-center px-4">
        {/* Heading */}
        <h1 className="text-2xl font-raleway font-bold tracking-[0.09em] text-white mb-6">
          LET THE NUMBERS TELL THE STORY
        </h1>

        {/* Stats in Row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 ">
          {/* First Stat */}
          <div>
            <h1 className="text-[80px] font-poppins font-bold text-[#20ce88]">
              80%
            </h1>
            <p className="text-md text-white font-poppins font-semibold">
              Faster Candidate Submission
            </p>
          </div>

          {/* Second Stat */}
          <div>
            <h1 className="text-[80px] font-poppins font-bold text-[#20ce88]">
              6 figure
            </h1>
            <h6 className="text-md text-white font-poppins font-semibold">
              Savings in year 1 unlocked by editing efficiencies  </h6>
          </div>

          {/* Third Stat */}
          <div>
            <h1 className="text-[80px] font-poppins font-bold text-[#20ce88]">
              20%
            </h1>
            <p className="text-md text-white font-poppins font-semibold">
              Boost in interviews
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
