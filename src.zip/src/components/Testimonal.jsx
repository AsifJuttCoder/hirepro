import React from 'react';

// SVG components for icons used in the design
const G2Icon = () => (
  <svg preserveAspectRatio="xMidYMid meet" viewBox="-0.002 -0.001 711.292 731.283" width="64" height="64" className="text-[#ff492c] h-16 w-16" role="presentation" aria-hidden="true">
    <g>
      <path d="M501.22 521c26.9 46.68 53.5 92.83 80.08 138.93-117.7 90.11-300.82 101-436.38-2.77-156-119.51-181.64-323.43-98.12-470.22C142.86 18.1 322.62-19.24 438.36 8.14c-3.13 6.8-72.45 150.61-72.45 150.61s-5.48.36-8.58.42c-34.21 1.45-59.69 9.41-87 23.53a206.93 206.93 0 0 0-109.84 159.76 201.7 201.7 0 0 0 13.68 100.29c11 26.82 26.56 50.64 47.42 70.75 32 30.88 70.08 50 114.22 56.33 41.8 6 82 .06 119.67-18.87 14.13-7.09 26.15-14.92 40.2-25.66 1.79-1.16 3.38-2.63 5.54-4.3" fill="currentColor"></path>
      <path d="M501.48 111.61c-6.83-6.72-13.16-12.92-19.46-19.16-3.76-3.72-7.38-7.59-11.23-11.22-1.38-1.31-3-3.1-3-3.1s1.31-2.78 1.87-3.92c7.37-14.79 18.92-25.6 32.62-34.2A90.65 90.65 0 0 1 553 26c22.93.45 44.25 6.16 62.24 21.54 13.28 11.35 20.09 25.75 21.29 42.94 2 29-10 51.21-33.83 66.71-14 9.12-29.1 16.17-44.24 24.52-8.35 4.61-15.49 8.66-23.65 17-7.18 8.37-7.53 16.26-7.53 16.26l108.47-.14v48.31H468.32v-4.67c-.64-23.74 2.13-46.08 13-67.64 10-19.78 25.54-34.26 44.21-45.41 14.38-8.59 29.52-15.9 43.93-24.45 8.89-5.27 15.17-13 15.12-24.21 0-9.62-7-18.17-17-20.84-23.58-6.36-47.58 3.79-60.06 25.37-1.82 3.15-3.68 6.28-6.04 10.32m209.81 358.04-91.41-157.86H438.99l-92 159.49h182.22l89.92 157.11z" fill="currentColor"></path>
    </g>
  </svg>
);

const ChevronLeftIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 200" className="w-2 h-4">
    <path d="M80.789 173.304 4.162 100.722l78.156-74.027 5.518 5.828-72.009 68.199 70.48 66.745-5.518 5.837z"></path>
  </svg>
);

const ChevronRightIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 200" className="w-2 h-4">
    <path d="m19.2 26.7 76.6 72.6-78.2 74-5.5-5.8 72-68.2-70.5-66.7 5.6-5.9z"></path>
  </svg>
);

const testimonials = [
  {
    image: 'https://static.wixstatic.com/media/f9fb77_45df2fcb341f417fb9cac11fbf09bff2~mv2.png/v1/fill/w_76,h_76,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/f9fb77_45df2fcb341f417fb9cac11fbf09bff2~mv2.png',
    title: 'Recruitment Consultant',
    company: 'Spencer Ogden',
    quote: "I use it every day to format CV's so that they look more professional before sending to clients.I have also managed to win multiple clients by presenting them with anonymous formatted CV's.The AI generation tool that creates a blurb of the CV saves me at least 20 minutes, and sells the candidate so well.",
    monetaryWin: '£40,000',
    timeSaved: '20 mins',
  },
  {
    image: 'https://static.wixstatic.com/media/f9fb77_f221234e0cda4b1583f7251705048daa~mv2.png/v1/fill/w_76,h_76,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/f9fb77_f221234e0cda4b1583f7251705048daa~mv2.png',
    title: 'Associate Director',
    company: 'Murray McIntosh',
    quote: 'We do a lot of anonymous shortlisting so having a template that allows us to automatically remove certain information is great! We can format CVs for anonymous shortlist quickly and with certainty. Our key client loves it! We work on a retained basis so have placed a few people this year.',
    monetaryWin: '£32,000',
    timeSaved: '5 mins',
  },
  {
    image: 'https://static.wixstatic.com/media/f9fb77_e51cb272709641d8b13a81129fb61e40~mv2.png/v1/fill/w_76,h_76,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/f9fb77_e51cb272709641d8b13a81129fb61e40~mv2.png',
    title: 'Principal Recruitment Consultant',
    company: 'Collins McNicholas',
    quote: 'This has literally changed my life! I am now able to overcome the dreaded PDF CVs and complicated formatted CVs within seconds, have my coversheet auto-populated with a summary of the candidate\'s experience and present this in a professional format to my clients. It is a game changer!',
    monetaryWin: '£50,000',
    timeSaved: '10-20 mins',
  },
  {
    image: 'https://static.wixstatic.com/media/f9fb77_93c90e82d3a3463bb78f22ff6dfcdc49~mv2.png/v1/fill/w_76,h_76,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/f9fb77_93c90e82d3a3463bb78f22ff6dfcdc49~mv2.png',
    title: 'Senior Recruitment Consultant',
    company: 'Engage Education',
    quote: 'I have landed multiple wins from the CVs made on HireAra! I took a CV into a client and they said how impressed they were by the presentation, I told them my secret was a magical tool that did it all for me in seconds and they loved it (and got bonus points for the honesty)',
    monetaryWin: 'around £250pppw',
    timeSaved: '15 mins',
  },
];

const TestimonialCard = ({ image, title, company, quote, monetaryWin, timeSaved }) => (
  <div className="bg-white p-6 rounded-lg shadow-md flex flex-col items-center text-center h-full border border-blue-500">
    <img src={image} alt="" width="61" height="61" className="rounded-full mb-4" />
    <p className="font-semibold text-sm" style={{ fontFamily: 'raleway, sans-serif' }}>{title}</p>
    <p className="text-xs font-bold text-gray-600 mb-4" style={{ fontFamily: 'poppins, sans-serif' }}>{company}</p>
    <p className="text-sm text-gray-700 flex-grow" style={{ fontFamily: 'poppins, sans-serif' }}>{quote}</p>
    <div className="mt-4 text-sm text-gray-800 italic font-bold" style={{ fontFamily: 'poppins, sans-serif' }}>
      <p>Monetary win: {monetaryWin}</p>
      <p>Time saved per CV : {timeSaved}</p>
    </div>
  </div>
);

const HireAraTestimonials = () => {
  return (
    <section className="bg-gray-50 py-16 px-4">
      <div className="max-w-7xl mx-auto">
        <h3 className="text-2xl text-center font-medium mb-12" style={{ fontFamily: 'poppins, sans-serif' }}>
          What they like about HireAra?
        </h3>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-4 mb-12 w-[70%] m-auto">
          {testimonials.map((testimonial, index) => (
            <TestimonialCard key={index} {...testimonial} />
          ))}
        </div>

        <div className="flex justify-center items-center space-x-2 text-sm text-gray-600 mb-12">
            <button className="p-2 border rounded-full text-gray-300 cursor-not-allowed" aria-label="Previous Page" disabled>
              <ChevronLeftIcon />
            </button>
            <span className="bg-blue-500 text-white w-6 h-6 flex items-center justify-center rounded-full text-xs">1</span>
            <a href="#" className="w-6 h-6 flex items-center justify-center rounded-full text-xs hover:bg-gray-200">2</a>
            <a href="#" className="w-6 h-6 flex items-center justify-center rounded-full text-xs hover:bg-gray-200">3</a>
            <a href="#" className="w-6 h-6 flex items-center justify-center rounded-full text-xs hover:bg-gray-200">4</a>
            <button className="p-2 border rounded-full hover:bg-gray-200" aria-label="Next Page">
              <ChevronRightIcon />
            </button>
        </div>

        <div className="text-center mb-12">
            <a href="https://www.hireara.ai/bookademo" target="_self" className="inline-block rounded-tr-lg rounded-bl-lg bg-blue-500 text-white font-semibold py-3 px-6  text-lg hover:bg-white hover:border hover:border-blue-500 hover:text-blue-500 transition-colors">
                Book a demo &gt;&gt;
            </a>
        </div>
        
        <div className="flex justify-center items-center flex-wrap gap-8">
            <div className="flex items-center gap-4">
              <a href="https://www.g2.com/products/hireara/reviews#reviews" target="_blank" rel="noreferrer noopener">
                <G2Icon/>
              </a>
              <div>
                <a href="https://www.g2.com/products/hireara/reviews#reviews" target="_blank" rel="noreferrer noopener">
                  <img
                    src="https://static.wixstatic.com/media/f9fb77_c974defd7d69453f9a82b82ffcdb15ab~mv2.png/v1/fill/w_112,h_23,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/Stars-41.png"
                    alt="4.9 Stars on G2"
                    className="h-5"
                  />
                  <p className="text-sm text-gray-700 underline mt-1"><span className="font-bold">26</span> reviews</p>
                </a>
              </div>
            </div>
            <div className="h-12 w-px bg-gray-300 hidden sm:block"></div>
            <div className="flex items-center gap-4">
               <a href="https://www.google.com/search?q=hireara#lrd=0x48761bc7b2925ccd:0xf08a5fbc343a7d1d,1,,," target="_blank" rel="noreferrer noopener">
                    <img
                        src="https://static.wixstatic.com/media/f9fb77_cc3bc9365a234d63aa76f265e697bd57~mv2.webp/v1/fill/w_33,h_23,al_c,q_80,usm_0.66_1.00_0.01,enc_avif,quality_auto/Google_Icons.webp"
                        alt="Google logo"
                        className="h-6"
                    />
               </a>
                <div>
                   <a href="https://www.google.com/search?q=hireara#lrd=0x48761bc7b2925ccd:0xf08a5fbc343a7d1d,1,,," target="_blank" rel="noreferrer noopener">
                    <img
                        src="https://static.wixstatic.com/media/f9fb77_292b332d5d1447f794ed9a4cca82f094~mv2.png/v1/fill/w_112,h_15,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/Google%20stars.png"
                        alt="5 Stars on Google"
                        className="h-4"
                    />
                    <p className="text-sm text-gray-700 underline mt-1"><span className="font-bold">14</span> reviews</p>
                   </a>
                </div>
            </div>
        </div>
      </div>
    </section>
  );
};

export default HireAraTestimonials;