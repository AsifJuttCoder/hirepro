import React from "react";

export default function Footer() {
  return (
    <footer className="bg-gray-200 w-[100%] m-auto mt-[50px] py-12 px-2 md:px-12 ">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-10 w-[76%]">
        {/* Logo + Refer */}
        <div>
          <img
            src="/images/hire.logo.avif"
            alt="HireAra Logo"
            className="w-40 mb-4"
          />
          <a
            className="text-green-600 font-bold underline text-sm"
          >
            Refer a company - get £300
          </a>
        </div>

        {/* Learn More */}
        <div>
          <h2 className="text-2xl font-semibold mb-4">Learn More</h2>
          <ul className="space-y-2 text-gray-600">
            <li>
              <a className="underline text-lg font-semibold">
                ROI Calculator
              </a>
            </li>
            <li>
              <a className="underline text-lg font-semibold">
                Pricing
              </a>
            </li>
            <li>
              <a className="underline text-lg font-semibold">
                Blogs
              </a>
            </li>
            <li>
              <a  className="underline text-lg font-semibold"
              >
                Careers
              </a>
            </li>
            <li>
              <a className="underline text-lg font-semibold">
                Status
              </a>
            </li>
          </ul>
        </div>

        {/* Security */}
        <div>
          <h2 className="text-2xl font-semibold mb-4">Security</h2>
          <ul className="space-y-2 text-gray-600">
            <li>
              <a className="underline text-lg font-semibold">
                Privacy Policy
              </a>
            </li>
            <li>
              <a className="underline text-lg font-semibold"
              >
                Terms of Use
              </a>
            </li>
            <li>
              <a className="underline text-lg font-semibold">
                Subprocessors
              </a>
            </li>
            <li>
              <a className="underline text-lg font-semibold">
                Modern Slavery Statement
              </a>
            </li>
            <li>
              <a className="underline text-lg font-semibold">
                HireAra AI Charter
              </a>
            </li>
            <li>
              <a className="underline text-lg font-semibold">
                Candidate FAQ
              </a>
            </li>
          </ul>
        </div>

        {/* Contact */}
        <div>
          <h2 className="text-2xl font-semibold mb-4">Contact Us</h2>
          <p className="text-gray-600 font-bold">
            <a href="mailto:hello@hireara.com" className="underline text-lg font-semibold">
              hello@hireara.com
            </a>
          </p>
          <p className="text-gray-600 text-lg mt-2">
            Armstrong Building Oakwood Drive, University Science &amp; Enterprise
            Park, Loughborough, England, LE11 3QF
          </p>

        </div>
      </div>
      
      <div className="border py-5 px-2 w-[60%] m-auto mt-8"></div>

      <h4 className="text-gray-600 text-lg text-center mt-16">This website and its content is copyright of © HireARA AI Limited 2025. All rights reserved.</h4>

     
    </footer>
  );
}
