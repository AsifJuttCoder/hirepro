import React from 'react';

const CandidateMarketing = () => {
  return (
    <section className="bg-[#0D1127] text-white font-sans pb-[150px] ">
      <div className="container mx-auto px-4 py-16  w-[80%] ">
        <div className="flex flex-wrap items-center">

          {/* Left Column: Text Content */}
          <div className=" md:w-1/2 lg:w-6/12 pr-4 ">
            <h1 className="text-5xl font-semibold leading-tight">
              <span className="text-white ">Take your </span><br />
              <span className="text-[#20ce87] font-bold">best candidates </span> <span className="text-white ">  to </span> <br />
              <span className="text-white "> market using HireAra</span>
            </h1>

            <div className="mt-12">
              <h2 className="text-3xl font-semibold">
                <span className="text-[#20ce87]">&gt;</span>
                <span className="text-white"> Spec CVs</span>
              </h2>
              <p className="text-white mt-5 ml-7 text-lg font-semibold leading-relaxed">
                A short, anonymous CV / Resume that highlights your candidate’s career, ideal for candidate-led outreach without revealing their identity.
              </p>
            </div>

            <div className="mt-8">
              <h2 className="text-3xl font-semibold">
                <span className="text-[#20ce87]">&gt;</span>
                <span className="text-white"> Landing Page</span>
              </h2>
              <p className="text-white mt-5 ml-7 text-lg font-semibold leading-relaxed">
               Build for maximum Outreach with real-time insights like link opens, view counts, and let leads book a call instantly with embedded calendar links. It’s not just a CV - it’s a warm lead, converted
              </p>
            </div>
          </div>

          {/* Right Column: Images */}
          <div className="w-full h-[550px] md:w-1/2 lg:w-6/12 mt-10 md:mt-0 relative  flex justify-center items-center">
          <div className=' h-[250px] w-[250px] rounded-2xl bg-[#112639] absolute top-[230px]'> </div>
            <div className="relative">
                {/* Main Image */}
                <div className="absolute top-[160px] right-[-240px] w-[750px] h-[279px] text-white hidden lg:block ">
                <img
                    src="/images/position-img-2.png"
                    alt="Landing page example"
                    className=""
                />
                </div>
               
            </div>

            {/* Smaller floating images - positioned absolutely relative to the column */}
            <div className="absolute top-[350px] right-[120px] w-[68px] h-[100px] hidden lg:block">
                 <img src="https://static.wixstatic.com/media/f9fb77_20978678e4d2418c82fd4f6408579ed5~mv2.png/v1/fill/w_68,h_100,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/Access%20Triangles-43-52.png" alt="Decorative Triangle" className="w-full h-full object-cover"/>
            </div>

            <div className="absolute top-[0px] right-[0px] w-[338px] h-[333px] hidden lg:block">
                <img src="/images/position-img-1.png" alt="CV Spec Example" className="w-full h-full object-cover"/>
            </div>

             <div className="absolute bottom-[170px] right-[80px] w-[40px] h-[36px] hidden lg:block">
                <img src="https://static.wixstatic.com/media/f9fb77_49134970c0144f5b89a4af0f23d7ef83~mv2.png/v1/fill/w_40,h_36,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/Access%20Triangles%20blue-58.png" alt="Decorative Blue Triangle" className="w-full h-full object-cover"/>
            </div>

          </div>
        </div>
      </div>
    </section>
  );
};

export default CandidateMarketing;