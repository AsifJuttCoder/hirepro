export default function TestimonialsSection() {
  return (
    <section className="bg-gradient-to-br from-[#10132b] to-[#277f96] my-[100px] py-16 px-6 text-center">
      {/* Heading */}
      <h3 className="text-1xl text-white font-bold tracking-wide">WHAT OUR CUSTOMERS SAY</h3>

      {/* Testimonial */}
      <h2 className="w-[57%] mt-8 text-3xl text-[#20cd88]  font-normal  mx-auto leading-relaxed">
        “With HireAra's professional, tailored CVs, our team members are securing
        more interviews and winning more opportunities."
      </h2>

      {/* Button */}
      <div className="mt-6">
        <a
          href="https://www.hireara.ai/customers"
          className="inline-block bg-transparent border-2 border-[#20cd88] text-white font-medium px-6 py-2 rounded-tr-xl rounded-bl-xl hover:bg-white hover:text-[#20cd88] transition"
        >
          See Customer Stories &gt;&gt;
        </a>
      </div>

      {/* Star Rating */}
      <div className="mt-8 flex justify-center">
        <img
          src="https://static.wixstatic.com/media/f9fb77_50c409070a484c4bb7e70db73707e829~mv2.png"
          alt="Rating stars"
          className="h-6"
        />
      </div>

      {/* Reviews */}
      
      <div className="mt-4 text-gray-300 text-sm space-x-2">
        <a
          href="https://uk.trustpilot.com/review/hireara.ai"
          target="_blank"
          rel="noreferrer"
          className="underline hover:text-white"
        >
          4.7 on TrustPilot
        </a>
        <span>|</span>
        <a
          href="https://www.g2.com/products/hireara/reviews#reviews"
          target="_blank"
          rel="noreferrer"
          className="underline hover:text-white"
        >
          4.6 on G2.com
        </a>
        <span>|</span>
        <a
          href="https://www.google.com/search?q=hireara#lrd=0x48761bc7b2925ccd:0xf08a5fbc343a7d1d,1"
          target="_blank"
          rel="noreferrer"
          className="underline hover:text-white"
        >
          4.7 on Google
        </a>
      </div>
    </section>
  );
}