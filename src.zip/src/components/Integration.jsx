export default function IntegrationSection() {
  return (
    <section className="bg-white py-20 ">
      <div className="max-w-[80%] mx-auto px-6 ">
        {/* Heading */}
        <h2 className="text-5xl md:text-6xl font-semibold leading-snug  w-[50%] ">
          <span className="text-blue-600 ">Integrated</span>{" "}
          <span className="">where you already work</span>
        </h2>

        {/* Buttons */}
        <div className="mt-8 py-5">
          <a
            href="#"
            className="px-10 py-2 border-2 border-blue-600 bg-blue-600 text-white rounded-tr-xl rounded-bl-xl hover:bg-white hover:text-blue-600"
          >
            Book a demo
          </a>
          <a
            href="#"
            className="p-2 border-2 ml-7 border-blue-600 bg-white text-blue-600 rounded-tr-xl rounded-bl-xl hover:bg-blue-600 hover:text-white"
          >
            Virtual Product demo
          </a>
        </div>

        {/* Features with Checkmarks */}
        <div className="mt-12 space-y-4 text-2xl font-semibold text-gray-700 ">
          <p>
            <span className="text-blue-600">&gt;&gt;</span> Create high-impact candidate submissions
          </p>
          <p>
            <span className="text-blue-600">&gt;&gt;</span> Ensure all data and content syncs effortlessly back to your CRM
          </p>
          <p>
            <span className="text-blue-600">&gt;&gt;</span> Share directly from your CRM
          </p>
        </div>

        {/* Logos Grid */}
        <div className="mt-10 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-8 w-[60%] text-center ">
          <a>
            <img
              src="https://static.wixstatic.com/media/f9fb77_3d9f90516ff54d85a12b698e8c5bfb79~mv2.png"
              alt="Access"
              className="h-16 mx-auto object-contain border-2 border-gray-300 rounded-lg transition-transform duration-300 ease-in-out hover:-translate-y-2"
            />
            <a href=""><p className="text-[12px] text-gray-500"><u>Access CRM</u></p></a>
          </a>
          <a>
            <img
              src="https://static.wixstatic.com/media/f9fb77_d3d4867d639b409f967324aca949c75b~mv2.png"
              alt="Vincere"
              className="h-16 mx-auto object-contain border-2 border-gray-300 rounded-lg transition-transform duration-300 ease-in-out hover:-translate-y-2"
            />
            <a href=""><p className="text-[13px] text-gray-500"><u>Vincere</u></p></a>
          </a>
          <a>
            <img
              src="https://static.wixstatic.com/media/f9fb77_ba83257bf7f24762bf79e2b78fc6d651~mv2.png"
              alt="Mercury"
              className="h-16 mx-auto object-contain border-2 border-gray-300 rounded-lg transition-transform duration-300 ease-in-out hover:-translate-y-2"
            />
            <a href=""><p className="text-[12px] text-gray-500"><u>Mercury</u></p></a>
          </a>
          <a>
            <img
              src="https://static.wixstatic.com/media/f9fb77_09ece7a14d4c4eac95011a0eb8df461c~mv2.png"
              alt="Salesforce"
              className="h-16 mx-auto object-contain border-2 border-gray-300 rounded-lg transition-transform duration-300 ease-in-out hover:-translate-y-2"
            />
            <a href=""><p className="text-[12px] text-gray-500"><u>Salesforce</u></p></a>
          </a>
          <a>
            <img
              src="https://static.wixstatic.com/media/f9fb77_3cf8ac38140a4ca4a3c0898b0e17d7af~mv2.png"
              alt="Bullhorn"
              className="h-16 mx-auto object-contain border-2 border-gray-300 rounded-lg transition-transform duration-300 ease-in-out hover:-translate-y-2"
            />
            <a href=""><p className="text-[12px] text-gray-500"><u>Bullhorn</u></p></a>
          </a>
          <a>
            <img
              src="https://static.wixstatic.com/media/f9fb77_afdf38aa8c7f470f9f50df798ff9540b~mv2.png"
              alt="Seven20"
              className="h-16 mx-auto object-contain border-2 border-gray-300 rounded-lg transition-transform duration-300 ease-in-out hover:-translate-y-2"
            />
            <a href=""><p className="text-[12px] text-gray-500"><u>Seven2o</u></p></a>
          </a>
          <a>
            <img
              src="https://static.wixstatic.com/media/f9fb77_39c48d7fef5f4ae6b21f27dcbab67989~mv2.png"
              alt="Recman"
              className="h-16 mx-auto object-contain border-2 border-gray-300 rounded-lg transition-transform duration-300 ease-in-out hover:-translate-y-2"
            />
            <a href=""><p className="text-[12px] text-gray-500"><u>Recman</u></p></a>
          </a>
          <a>
            <img
              src="https://static.wixstatic.com/media/f9fb77_80e9b2092435451f8004ecf6de2baac3~mv2.png"
              alt="Bullhorn for Salesforce"
              className="h-16 mx-auto object-contain border-2 border-gray-300 rounded-lg transition-transform duration-300 ease-in-out hover:-translate-y-2"
            />
            <a href=""><p className="text-[12px] text-gray-500"><u>Bullhorn for salesforce</u></p></a>
          </a>
        </div>
      </div>
    </section>
  );
}
