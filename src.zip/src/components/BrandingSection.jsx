export default function BrandingSection() {
  return (
    <section className="w-full py-16  bg-gradient-to-b from-white to-[#d8f1f5]">
      <div className="max-w-[80%] mx-auto grid md:grid-cols-[40%_60%] gap-6 items-center px-6 border-14 border-gray-200 bg-white">
        {/* Left Content */}
        <div className=" w-[85%] ">  
          <h3 className="text-lg font-raleway font-semibold text-gray-500 mb-10">
            FEATURES
          </h3>
          <h2 className="text-3xl font-raleway font-bold text-gray-800 leading-snug my-8">
            AI personalised submissions at scale
          </h2>
          <p className="text-lg text-gray-600 font-poppins leading-relaxed my-8">
            Ensure that all written content you submit is{" "}
            <span className="italic font-bold text-blue-600">
              personalised and tailored to the job.
            </span>{" "}
            Beat bland AI and discover conversion optimised content.
          </p>
          <a
          href="#"
          className="px-10 py-2  border-2 text-xl font-semibold border-blue-600 bg-blue-600 text-white rounded-tr-xl rounded-bl-xl hover:bg-white hover:text-blue-600"
        >
          Try it &gt;&gt;
        </a>
        </div>

        {/* Right Content - Video */}
        <div className="rounded-2xl overflow-hidden">
          <video
            className="w-full h-full object-cover"
            src="/images/Candidate-video-1.mp4"
            autoPlay
            loop
            muted
            playsInline
          />
        </div>
      </div>

       <div className="max-w-[80%] mx-auto grid md:grid-cols-[40%_60%]  gap-6 items-center px-6 my-24 border-14 border-gray-200 bg-white">
        {/* Left Content */}
        <div className=" w-[85%] ">
          <h3 className="text-lg font-raleway font-semibold text-gray-500 mb-10">
            FEATURES
          </h3>
          <h2 className="text-3xl font-raleway font-bold text-gray-800 leading-snug my-8">
            Candidate websites <br /> in 1 click
          </h2>
          <p className="text-lg text-gray-600 font-poppins leading-relaxed my-8">
            Ensure that all written content you submit is{" "}
            <span className="italic font-bold text-blue-600">
              personalised and tailored to the job.
            </span>{" "}
            Beat bland AI and discover conversion optimised content.
          </p>
          <a
          href="#"
          className="px-10 py-2  border-2 text-xl font-semibold border-blue-600 bg-blue-600 text-white rounded-tr-xl rounded-bl-xl hover:bg-white hover:text-blue-600"
        >
          Try it &gt;&gt;
        </a>
        </div>

        {/* Right Content - Video */}
        <div className="rounded-2xl overflow-hidden ">
          <video
            className="w-full h-full object-cover"
            src="/images/Candidate-video-2.mp4"
            autoPlay
            loop
            muted
            playsInline
          />
        </div>
      </div>

       <div className="max-w-[80%] mx-auto grid md:grid-cols-[40%_60%]  gap-6 items-center px-6 border-14 border-gray-200 bg-white">
        {/* Left Content */}
        <div className=" w-[100%] ">
          <h3 className="text-lg font-raleway font-semibold text-gray-500 mb-10">
            FEATURES
          </h3>
          <h2 className="text-3xl font-raleway font-bold text-gray-800 leading-snug my-8 ">
            More Candidate Content then ever before
          </h2>
          <p className="text-lg text-gray-600 font-poppins leading-relaxed my-8 w-[85%]">
            Ensure that all written content you submit is{" "}
            <span className="italic font-bold text-blue-600">
              personalised and tailored to the job.
            </span>{" "}
            Beat bland AI and discover conversion optimised content.
          </p>
          <a
          href="#"
          className="px-10 py-2  border-2 text-xl font-semibold border-blue-600 bg-blue-600 text-white rounded-tr-xl rounded-bl-xl hover:bg-white hover:text-blue-600"
        >
          Try it &gt;&gt;
        </a>
        </div>

        {/* Right Content - Video */}
        <div className="rounded-2xl overflow-hidden ">
          <video
            className="w-full h-full object-cover"
            src="/images/Candidate-video-3.mp4"
            autoPlay
            loop
            muted
            playsInline
          />
        </div>
      </div>
    </section>
  );
}
