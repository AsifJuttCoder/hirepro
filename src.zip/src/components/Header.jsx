import { useState } from "react";
import { ChevronDown, Menu, X } from "lucide-react";

export default function Header() {
  const [openDropdown, setOpenDropdown] = useState(null);
  const [mobileMenu, setMobileMenu] = useState(false);

  const toggleDropdown = (menu) => {
    setOpenDropdown(openDropdown === menu ? null : menu);
  };

  return (
    <header className="w-full bg-white sticky top-0 z-10">
      <div className="max-w-7xl mx-auto flex items-center justify-between px-6 py-3 ">
        {/* Left Side (Logo + Navigation) */}
        <div className="flex items-center gap-10 relative left-[10%] ">
          {/* Logo */}
          <a href="">
            <img
              src="/images/hire.logo.avif"
              alt="HireAra Logo"
              className="h-15"
            />
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex gap-6 items-center">
            <div className="relative">
              <button
                onClick={() => toggleDropdown("product")}
                className="text-base font-normal flex items-center gap-1 hover:text-blue-600"
              >
                Product <ChevronDown size={16} />
              </button>
              {openDropdown === "product" && (
                <ul className="absolute mt-2 bg-white rounded-md w-48 p-2 shadow-lg">
                  <li>
                    <a
                      href="https://www.hireara.ai/virtual-product-demo"
                      className="block px-3 py-2 hover:bg-gray-100"
                    >
                      Virtual Product Demo
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://www.hireara.ai/templates"
                      className="block px-3 py-2 hover:bg-gray-100"
                    >
                      Content Templates
                    </a>
                  </li>
                </ul>
              )}
            </div>

            <div className="relative">
              <button
                onClick={() => toggleDropdown("pricing")}
                className="text-base font-normal flex items-center gap-1 hover:text-blue-600"
              >
                Pricing <ChevronDown size={16} />
              </button>
              {openDropdown === "pricing" && (
                <ul className="absolute mt-2 bg-white rounded-md w-48 p-2 shadow-lg">
                  <li>
                    <a
                      href="https://www.hireara.ai/roi-calculator"
                      className="block px-3 py-2 hover:bg-gray-100"
                    >
                      ROI Calculator
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://www.hireara.ai/refer-a-friend"
                      className="block px-3 py-2 hover:bg-gray-100"
                    >
                      Refer a Friend
                    </a>
                  </li>
                </ul>
              )}
            </div>

            <a
              href="https://www.hireara.ai/customers"
              className="text-base font-normal hover:text-blue-600"
            >
              Customers
            </a>

            <div className="relative">
              <button
                onClick={() => toggleDropdown("more")}
                className="text-base font-normal flex items-center gap-1 hover:text-blue-600"
              >
                More <ChevronDown size={16} />
              </button>
              {openDropdown === "more" && (
                <ul className="absolute mt-2 bg-white rounded-md w-48 p-2 shadow-lg">
                  <li>
                    <a
                      href="https://www.hireara.ai/blogs"
                      className="block px-3 py-2 hover:bg-gray-100"
                    >
                      Blogs
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://www.notion.so/hireara/Careers-11af260b904c80898f52cacc2c2d24b8?pvs=4"
                      target="_blank"
                      rel="noreferrer"
                      className="block px-3 py-2 hover:bg-gray-100"
                    >
                      Careers
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://www.hireara.ai/security"
                      className="block px-3 py-2 hover:bg-gray-100"
                    >
                      Security
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://help.hireara.ai/en"
                      target="_blank"
                      rel="noreferrer"
                      className="block px-3 py-2 hover:bg-gray-100"
                    >
                      Help Centre
                    </a>
                  </li>
                </ul>
              )}
            </div>
          </nav>
        </div>

        {/* Right Side Buttons (10% left shift) */}
        <div className="hidden md:flex items-center gap-6 relative right-[10%]">
          <a
            href="https://www.present.hireara.ai/"
            target="_blank"
            rel="noreferrer"
            className="text-base font-normal text-gray-700 border-b-2 border-sky-400 pb-1 hover:text-blue-600"
          >
            Log in
          </a>
          <a
            href="https://www.hireara.ai/bookademo"
            className="px-6 py-2 text-base font-medium bg-blue-600 text-white rounded-tr-xl rounded-bl-xl hover:bg-blue-700"
          >
            Book a demo
          </a>
        </div>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden"
          onClick={() => setMobileMenu(!mobileMenu)}
        >
          {mobileMenu ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {/* Mobile Navigation */}
      {mobileMenu && (
        <nav className="md:hidden bg-white p-4 flex flex-col gap-3">
          <button
            onClick={() => toggleDropdown("product")}
            className="flex items-center justify-between"
          >
            Product <ChevronDown size={16} />
          </button>
          {openDropdown === "product" && (
            <div className="pl-4 flex flex-col gap-2">
              <a href="https://www.hireara.ai/virtual-product-demo">
                Virtual Product Demo
              </a>
              <a href="https://www.hireara.ai/templates">Content Templates</a>
            </div>
          )}

          <button
            onClick={() => toggleDropdown("pricing")}
            className="flex items-center justify-between"
          >
            Pricing <ChevronDown size={16} />
          </button>
          {openDropdown === "pricing" && (
            <div className="pl-4 flex flex-col gap-2">
              <a href="https://www.hireara.ai/roi-calculator">ROI Calculator</a>
              <a href="https://www.hireara.ai/refer-a-friend">Refer a Friend</a>
            </div>
          )}

          <a href="https://www.hireara.ai/customers">Customers</a>

          <button
            onClick={() => toggleDropdown("more")}
            className="flex items-center justify-between"
          >
            More <ChevronDown size={16} />
          </button>
          {openDropdown === "more" && (
            <div className="pl-4 flex flex-col gap-2">
              <a href="https://www.hireara.ai/blogs">Blogs</a>
              <a href="https://www.notion.so/hireara/Careers-11af260b904c80898f52cacc2c2d24b8?pvs=4">
                Careers
              </a>
              <a href="https://www.hireara.ai/security">Security</a>
              <a href="https://help.hireara.ai/en">Help Centre</a>
            </div>
          )}

          <div className="flex flex-col gap-2 mt-4">
            <a
              href="https://www.present.hireara.ai/"
              className="px-4 py-2 text-center text-gray-700 border-b-2 border-sky-400"
            >
              Log in
            </a>
            <a
              href="https://www.hireara.ai/bookademo"
              className="px-6 py-2 bg-blue-600 text-white rounded-tr-xl rounded-bl-xl text-center"
            >
              Book a demo
            </a>
          </div>
        </nav>
      )}
    </header>
  );
}
