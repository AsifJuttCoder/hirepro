// FeatureSection.jsx
import React from "react";

export default function FeatureSection() {
  const features = [
    {
      title: "BUSINESS DEVELOPMENT",
      image:
        "https://static.wixstatic.com/media/f9fb77_147ca9dec8bb464f8f4284cb102cd325~mv2.png",
      heading: "genuinely drives business",
      heading1: "development",
      description:
        "Leverage your candidate as a business development asset. HireAra is proven to increase candidate-led outbound quality, volume and conversion.",
    },
    {
      title: "BRAND",
      image:
        "https://static.wixstatic.com/media/f9fb77_5462afc705e54427a5911f807e815a54~mv2.png",
      heading: "makes your brand look",
      heading1: "world-class",
      description:
        "We’ve proven that changing only the design of a CV can lead to a 20% higher interview rate. Branding impact placements.",
    },
    {
      title: "TIME",
      image:
        "https://static.wixstatic.com/media/f9fb77_2f498727649a458d80afaaddff87473b~mv2.png",
      heading: "actually saves",
      heading1: "time",
      description:
        "Let your recruiters spend more time talking to candidates and clients rather than formatting CVs manually.",
    },
  ];

  return (
    <section className="w-full py-16 bg-gray-50">
      {/* Heading + Button */}
      <div className="w-[65%] py-5 mb-10 m-auto flex justify-between items-center">
        <h1 className="text-5xl font-semibold">The first AI tool that…</h1>
        <a
          href="#"
          className="px-10 py-2 border-2 text-xl font-semibold border-blue-600 bg-blue-600 text-white rounded-tr-xl rounded-bl-xl hover:bg-white hover:text-blue-600"
        >
          Calculate ROI &gt;&gt;
        </a>
      </div>

      {/* Feature Cards */}
      <div className="max-w-6xl mx-auto px-6 grid md:grid-cols-3 gap-6 text-center">
        {features.map((feature, index) => (
          <div
            key={index}
            className="rounded-2xl overflow-hidden shadow-lg border-2 border-gray-300 pt-5 
                       transition-transform duration-300 ease-in-out hover:-translate-y-3 hover:shadow-xl"
          >
            {/* Card Title */}
            <a
              href="#"
              target="_self"
              className="hover:text-blue-600 text-gray-500 text-lg"
            >
              {feature.title}
            </a>

            {/* Image */}
            <div className="bg-white p-6 flex justify-center items-center">
              <img
                src={feature.image}
                alt={feature.title}
                className="h-38 object-contain"
              />
            </div>

            {/* Content */}
            <div className="bg-[#f3f1fc] p-6 text-center h-[270px]">
              <h4 className="text-xl font-semibold italic text-gray-800 mb-4">
                {feature.heading}
              </h4>
              <h4 className="text-xl font-semibold italic text-blue-600 mb-4">
                {feature.heading1}
              </h4>
              <p className="text-gray-600 text-base leading-relaxed">
                {feature.description}
              </p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
